<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-title">Post create</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('posts.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Title</label>
                      <input type="text" class="form-control" name="title" id="exampleInputEmail1" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="description">Description</label>
                        <textarea name="description" id="" cols="50" rows="6"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
            </div>
        </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('posts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrudOperation\resources\views/posts/create.blade.php ENDPATH**/ ?>