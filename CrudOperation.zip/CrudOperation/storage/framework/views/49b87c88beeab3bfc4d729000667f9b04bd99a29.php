<?php $__env->startSection('title','All Post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <a class="btn btn-primary mb-4" href="<?php echo e(route('posts.create')); ?>">Create</a>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-title">
                    All Posts
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($data->id); ?></td>
                                <td><?php echo e($data->title); ?></td>
                                <td><?php echo e($data->description); ?></td>
                                <td>
                                    <a href="<?php echo e(route('posts.edit',$data->id)); ?>" class="btn btn-success">Edit</a>
                                    <form action="<?php echo e(route('posts.destroy',$data->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="50">No Data found</td>
                              </tr>
                            <?php endif; ?>


                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('posts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrudOperation\resources\views/posts/post.blade.php ENDPATH**/ ?>