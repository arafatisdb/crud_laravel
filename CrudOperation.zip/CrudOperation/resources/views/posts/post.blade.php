@extends('posts.layout')
@section('title','All Post')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <a class="btn btn-primary mb-4" href="{{ route('posts.create') }}">Create</a>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-title">
                    All Posts
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            @forelse ($datas as $data)
                            <tr>
                                <td>{{ $data->id }}</td>
                                <td>{{ $data->title }}</td>
                                <td>{{ $data->description}}</td>
                                <td>
                                    <a href="{{ route('posts.edit',$data->id) }}" class="btn btn-success">Edit</a>
                                    <form action="{{ route('posts.destroy',$data->id) }}" method="post">
                                        @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                              </tr>
                            @empty
                            <tr>
                                <td colspan="50">No Data found</td>
                              </tr>
                            @endforelse


                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
@endsection
