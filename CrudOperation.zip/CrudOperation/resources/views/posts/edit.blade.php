@extends('posts.layout')
@section('title','Eidt Post')
@section('content')
  <div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-title">Post Edit</div>
            <div class="card-body">
                <form method="PUT" action="{{ route('posts.update',$post_id->id) }}">
                    @csrf
                    @method('PUT')
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Title</label>
                      <input type="text" value="{{ $post_id->title }}" class="form-control" name="title" id="exampleInputEmail1" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="description">Description</label>
                        <textarea name="description" id="" cols="50" rows="6">{{ $post_id->description }}</textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
            </div>
        </div>
    </div>
  </div>


@endsection
