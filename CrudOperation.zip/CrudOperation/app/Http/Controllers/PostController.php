<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    public function index()
    {
        $datas = Post::orderby('id','desc')->paginate(5);
        return view('posts.post',compact('datas'));
    }
    public function create()
    {
        return view('posts.create');
    }
    public function store(Request $request)
    {
        $validator= Validator::make($request->all(),[
            'title'=>'required',
            'description'=>'required',
        ]);
        // $post = new Post;
        // $post->title = $request->title;
        // $post->description = $request->description;
        // $post->image = $path;
        // $post->save();

        Post::create([
            'title'=>$request->title,
            'description'=>$request->description,
        ]);

        return redirect()->route('posts.index')->with('success','Post has been saved succesfully.');
    }
    public function show(Post $post)
    {
        return view('posts.post',compact('post'));
    }
    public function edit($id)
    {
        $post_id = Post::find($id);
        return view('posts.edit',compact('post_id'));

    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'title'=>'required',
            'description'=>'required',
        ]);
        $post = Post::find($id);
        $post->update([
            'title'=>$request->title,
            'description'=>$request->description,
        ]);
        return redirect()->route('posts.index')->with('success','Post has been updated succesfully.');
    }
    public function destroy($id)
    {
        $post_id = Post::find($id);
        $post_id->delete();
        return redirect()->route('posts.index')->with('success','Post Has been deleted succesfully.');
    }
}
